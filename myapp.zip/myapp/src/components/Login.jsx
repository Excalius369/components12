import { TextField, Typography } from '@mui/material'
import React from 'react'

const Login = () => {
  return (
    <div>
        {/* <Typography variant='h3'>Hello</Typography>
        <TextField variant='outlined'label='username'/><br /><br />
        <button>Submit</button> */}
    </div>
  )
}

export default Login