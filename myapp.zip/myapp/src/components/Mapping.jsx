import React, { useState } from 'react'

const Mapping = () => {
    var[name,setname]=useState(["Alan","Abhianv","Jubin"]);
  return (
    <div>
        <ol>
            {name.map((value,index)=>{
                return(
                    <li>{value}</li>
                )
            })}
        </ol>
    </div>
  )
}

export default Mapping