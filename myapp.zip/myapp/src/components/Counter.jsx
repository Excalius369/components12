import { Button, Typography } from '@mui/material'
import React, { useState } from 'react'

const Counter = () => {
    var [num,setnum]=useState(0)
    const onplus=()=>{
        num=num+1;
        setnum(num);
    };
    const onminus=()=>{
        if(num>0){
        num=num-1;
        setnum(num);
        }
    };
  return (
    <div>
        <Typography>Count:{num}</Typography>
        <Button variant="contained" color="success" onClick={onplus}>+</Button>&nbsp; &nbsp;
        <Button variant="contained" color="error" onClick={onminus}>-</Button>
    </div>
  )
}

export default Counter