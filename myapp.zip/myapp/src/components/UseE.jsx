import { Button, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'

const UseE = () => {
    var[here,sethere]=useState("");
    const onhome=()=>{
        sethere("Home");
    }
    const oncontact=()=>{
        sethere("Contact");
    }
    const ongallery=()=>{
        sethere("Gallery")
    }
    useEffect(()=>{onhome()},[])
  return (
    <div>
        <Typography>Welcome to {here}</Typography>
        <Button variant='contained' onClick={onhome}>Home</Button>&nbsp; &nbsp;
        <Button variant='contained' onClick={oncontact}>Contact</Button>&nbsp; &nbsp;
        <Button variant='contained' onClick={ongallery}>Gallery</Button>
    </div>
  )
}

export default UseE