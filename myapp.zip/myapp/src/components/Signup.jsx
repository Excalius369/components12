import { Button, TextField, Typography } from '@mui/material'
import React from 'react'

const Signup = () => {
  return (
    <div>
        <Typography variant='h3'>Signup</Typography><br /> <br />
        <TextField variant='outlined'label='Name'/><br /><br />
        <TextField variant='outlined'label='Email'/><br /><br />
        <TextField variant='outlined'label='Place'/><br /><br />
        <TextField variant='outlined'label='Age'/><br /><br />
        <TextField variant='outlined' label='Gender'/><br /><br />
        <TextField variant='outlined'label='Passsword'type='password'/><br /><br />
        <Button variant='contained'>Sign up</Button>
    </div>
  )
}

export default Signup