import { Button, ButtonBase, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'

const StateBasics = () => {
    //var name="Abhinav;"
    var [fname,setfname]=useState("Abhinav");
    var[va1,setva1]=useState()
    const changeName =() =>{
        console.log("Clicked")
        setfname(va1)
        setva1('')
    }
    const inputhandler=(e)=>{
        console.log(e.target.value)
        setva1(e.target.value)

    }
  return (
    <div>
        <Typography>My Name is {fname}</Typography><br /><br />
        <TextField variant='outlined' label='Enter name' onChange={inputhandler}/>
        <br /><br />
        <Button variant='contained' onClick={changeName}>Change</Button>
    </div>
  );
};

export default StateBasics;